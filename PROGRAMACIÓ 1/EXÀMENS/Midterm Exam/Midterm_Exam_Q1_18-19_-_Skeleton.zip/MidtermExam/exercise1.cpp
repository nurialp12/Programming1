/*********************************************************************
 *                       TYPE YOUR NAME HERE                         *
 *********************************************************************/

/*
NOTE: The first dimension corresponds to the rows, and the second
      one correspond to the colums. So to access element at row 3
	  and column 5 you would write something like board[3][5].
*/
unsigned int countCompleteLines(int board[10][10])
{
	// TODO: Insert your code here
	return 0;
}
