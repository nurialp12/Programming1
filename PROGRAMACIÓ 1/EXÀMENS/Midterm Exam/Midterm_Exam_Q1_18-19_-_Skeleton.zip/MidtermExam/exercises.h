#pragma once

// Function declarations
unsigned int countCompleteLines(int board[10][10]);
unsigned int isPalindrome(const char word[]);
unsigned int sumDivisiblesBy5InRange(int begin, int end);
