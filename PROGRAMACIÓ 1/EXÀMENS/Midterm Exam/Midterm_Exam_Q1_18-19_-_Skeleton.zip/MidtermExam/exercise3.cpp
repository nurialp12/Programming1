/*********************************************************************
 *                       TYPE YOUR NAME HERE                         *
 *********************************************************************/

unsigned int sumDivisiblesBy5InRange(int begin, int end)
{
	// TODO: Insert your code here
	return 0;
}
