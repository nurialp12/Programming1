/*********************************************************************
 *                       TYPE YOUR NAME HERE                         *
 *********************************************************************/

unsigned int isPalindrome(const char word[])
{
	// TODO: Insert your code here
	return 0;
}
