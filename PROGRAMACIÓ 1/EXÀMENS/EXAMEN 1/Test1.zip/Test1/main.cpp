/*******************************************************/
/*                 TYPE YOUR NAME HERE                 */
/*******************************************************/

#include <stdio.h>
#include <stdlib.h>

int main()
{
	/* TODO: Insert your code here. */

	system("pause");
	return 0;
}
