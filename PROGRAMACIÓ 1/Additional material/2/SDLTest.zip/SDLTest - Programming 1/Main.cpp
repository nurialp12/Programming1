/**********************************************************************
 *
 * IMPORTANT NOTE:
 * Make sure you compile the project in x86 architecture.
 * If you see x64 in the combo box above, change it to x86.
 * This is because the libraries we are using (SDL, libpng, etc) are
 * compiled in x86 architecture, so we have to adapt.
 *
 **********************************************************************/

#pragma comment(linker,"/ENTRY:mainCRTStartup")
#pragma comment(linker,"/SUBSYSTEM:WINDOWS")

#include <stdlib.h>
#include "sdl_functions.h"


int main(int argc, char* argv[])
{
	// Initialize SDL
	if (Init() == 0) {
		return 1;
	}

	// Load a texture
	SDL_Texture *megaman = LoadTexture("Assets/Sprites/megaman.gif");
	SDL_Texture *screen = LoadTexture("Assets/Screens/screen01.png");

	while (exitApplication != 1)
	{
		PreUpdate(); // Updates events

		SDL_Rect rect;

		/* Draw the screen */
		rect.x = 0;
		rect.y = 0;
		rect.w = 640;
		rect.h = 480;
		Blit(screen, 0, 0, &rect);

		/* Draw megaman */
		rect.x = 114;
		rect.y = 426;
		rect.w = 34;
		rect.h = 48;
		Blit(megaman, 40, 105, &rect);

		PostUpdate(); // Renders the screen
	}

	// Unload textures
	UnloadTexture(megaman);
	UnloadTexture(screen);

	// Finalize SDL
	CleanUp();

	return 0;
}
